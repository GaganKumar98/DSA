package com.gagan.dsa;

public class Gcd {
	public int getGcd(int num1, int num2) {
		while(num1!=num2) {
			if(num1>num2) {
				num1=num1-num2;
				System.out.println("Number 1 : "+num1);
			}
			else {
				num2=num2-num1;
				System.out.println("Number 2 : "+num2);
			}
		}
		return num1;
	}
}
