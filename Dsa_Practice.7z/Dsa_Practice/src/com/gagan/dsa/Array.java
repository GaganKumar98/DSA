package com.gagan.dsa;

public class Array {

}
